<!DOCTYPE html>
<html>
<head>
	<title>Team Project One</title>
	<link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">
	<link href="stylesheet/formCSS.css" rel="stylesheet">
<style>
body {
  background-image: url("img/blackbackground.png");
}
</style>	
</head>
<body>
<?php
include('InventoryConnection.php'); //DB connection
$dbAction =  $_GET['action']; //receive action for form


//START
if($dbAction == "update"){
	$Count	= $_GET['id'];
	$select = "SELECT * FROM RoomComputers WHERE Count = $Count";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();
		$Count = $row['Count'];
		$RoomID = $row['RoomID'];
		$BuildingID = $row['BuildingID'];
		$ComputerID = $row['ComputerID'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Room Computers form
		</legend>
		<label for="Count">Count</label>
		<input type="text" name="Count" id="Count" value="<?php echo $Count ?>" required><br>
		<label for="RoomID">Room ID</label>
		<input type="text" name="RoomID" id="RoomID" value="<?php echo $RoomID ?>" required><br>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" value="<?php echo $BuildingID ?>" required><br>
		<label for="ComputerID">Computer ID</label>
		<input type="text" name="ComputerID" id="ComputerID" value="<?php echo $ComputerID ?>" required><br>
		
		<button type="submit" name="update">Update</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['update'])){
		$Count = $_POST['Count'];
		$RoomID = $_POST['RoomID'];
		$BuildingID = $_POST['BuildingID'];
		$ComputerID = $_POST['ComputerID'];
		$sql = "UPDATE RoomComputers SET Count='$Count', RoomID='$RoomID', BuildingID='$BuildingID', ComputerID='$ComputerID' WHERE Count ='$Count'";
		$conn->query($sql);
		//echo $Count.' '.$RoomID.' '.$BuildingID. ' ' .$ComputerID;
		header('Location: roomcomputers.php');
	}
}
else if($dbAction == "delete"){
	$Count = $_GET['id'];
	
	$select = "SELECT * FROM roomcomputers WHERE Count = $Count";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();	
		$Count = $row['Count'];
		$RoomID = $row['RoomID'];
		$BuildingID = $row['BuildingID'];
		$ComputerID = $row['ComputerID'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Room Computers form
		</legend>
		<label for="Count">Count</label>
		<input type="text" name="Count" id="Count" value="<?php echo $Count ?>" required><br>
		<label for="RoomID">Room ID</label>
		<input type="text" name="RoomID" id="RoomID" value="<?php echo $RoomID ?>" required><br>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" value="<?php echo $BuildingID ?>" required><br>
		<label for="ComputerID">Computer ID</label>
		<input type="text" name="ComputerID" id="ComputerID" value="<?php echo $ComputerID ?>" required><br>
		
		<button type="submit" name="delete">Delete</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['delete'])){
		$Count = $_POST['Count'];
		$sql = "DELETE FROM roomcomputers WHERE Count=$Count";
		$conn->query($sql);
		//echo $Count.' '.$RoomID.' '.$BuildingID. ' ' .$ComputerID;
		header('Location: roomcomputers.php');
	}
}
else if($dbAction == "insert"){
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Room Computers form
		</legend>
		<label for="RoomID">Room ID</label>
		<input type="text" name="RoomID" id="RoomID" required><br>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" required><br>
		<label for="ComputerID">Computer ID</label>
		<input type="text" name="ComputerID" id="ComputerID" required><br>
		
		<button type="submit" name="insert">Insert</button>

		</fieldset>
	</form>
<?php
		if(isset($_POST['insert'])){
			$RoomID = $_POST['RoomID'];
			$BuildingID = $_POST['BuildingID'];
			$ComputerID = $_POST['ComputerID'];
			$sql = "INSERT INTO roomcomputers (RoomID, BuildingID, ComputerID) VALUES('$RoomID', '$BuildingID', '$ComputerID')";
			
			$conn->query($sql);
			//echo $sql;
			//echo $RoomID.' '.$BuildingID. ' ' .$ComputerID;
			header('Location: roomcomputers.php');
		}
}else{
	echo 'Something went really wrong here!';
}
//END
$conn = null;
?>
<div id="footer"></div>
<footer>
			<em>
			<img src="img/group-icon2.png" alt="group icon" height="3%" width="3%">
			<br>Darly Dubreus, Grace Hechavarria, Mathew Maxwell, 
			<br>Manuel Pena, Gregory Toussaint
			<br>copyright &copy; 2019
			</em>
		</footer>

</body>
</html>