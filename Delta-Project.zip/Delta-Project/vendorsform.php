<!DOCTYPE html>
<html>
<head>
	<title>Team Project One</title>
	<link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">
	<link href="stylesheet/formCSS.css" rel="stylesheet">
<style>
body {
  background-image: url("img/blackbackground.png");
}
</style>	
</head>
<body>
<?php
include('InventoryConnection.php'); //DB connection
$dbAction =  $_GET['action']; //receive action for form


//START
if($dbAction == "update"){
	$vendorID	= $_GET['id'];
	$select = "SELECT * FROM vendors WHERE vendorID = $vendorID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();
		$VendorID = $row['VendorID'];
		$Name = $row['Name'];
		$Phone = $row['Phone'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Vendors form
		</legend>
		<label for="VendorID">Vendor</label>
		<input type="text" name="VendorID" id="VendorID" value="<?php echo $VendorID ?>" required><br>
		<label for="Name">Name</label>
		<input type="text" name="Name" id="Name" value="<?php echo $Name ?>" required><br>
		<label for="Phone">Phone</label>
		<input type="text" name="Phone" id="Phone" value="<?php echo $Phone ?>" required><br>
		
		<button type="submit" name="update">Update</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['update'])){
		$VendorID = $_POST['VendorID'];
		$Name = $_POST['Name'];
		$Phone = $_POST['Phone'];
		$sql = "UPDATE vendors SET VendorID='$VendorID', Name='$Name', Phone='$Phone' WHERE VendorID ='$VendorID'";
		$conn->query($sql);
		//echo $VendorID.' '.$Name.' '.$Phone;
		header('Location: vendors.php');
	}
}
else if($dbAction == "delete"){
	$VendorID = $_GET['id'];
	
	$select = "SELECT * FROM vendors WHERE VendorID = $VendorID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();	
		$VendorID = $row['VendorID'];
		$Name = $row['Name'];
		$Phone = $row['Phone'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Vendors form
		</legend>
		<label for="VendorID">Vendor</label>
		<input type="text" name="VendorID" id="VendorID" value="<?php echo $VendorID ?>" required><br>
		<label for="Name">Name</label>
		<input type="text" name="Name" id="Name" value="<?php echo $Name ?>" required><br>
		<label for="Phone">Phone</label>
		<input type="text" name="Phone" id="Phone" value="<?php echo $Phone ?>" required><br>
		
		<button type="submit" name="delete">Delete</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['delete'])){
		$VendorID = $_POST['VendorID'];
		$sql = "DELETE FROM vendors WHERE VendorID=$VendorID";
		$conn->query($sql);
		//echo $VendorID.' '.$Name.' '.$Phone;
		header('Location: vendors.php');
	}
}
else if($dbAction == "insert"){
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Vendors form
		</legend>
		<label for="Name">Name</label>
		<input type="text" name="Name" id="Name" required><br>
		<label for="Phone">Phone</label>
		<input type="text" name="Phone" id="Phone" required><br>
		
		<button type="submit" name="insert">Insert</button>

		</fieldset>
	</form>
<?php
		if(isset($_POST['insert'])){
			$Name = $_POST['Name'];
			$Phone = $_POST['Phone'];
			$sql = "INSERT INTO vendors (Name, Phone) VALUES('$Name', '$Phone')";
			
			$conn->query($sql);
			//echo $sql;
			//echo $Name.' '.$Phone;
			header('Location: vendors.php');
		}
}else{
	echo 'Something went really wrong here!';
}
//END
$conn = null;
?>
<div id="footer"></div>
<footer>
			<em>
			<img src="img/group-icon2.png" alt="group icon" height="3%" width="3%">
			<br>Darly Dubreus, Grace Hechavarria, Mathew Maxwell, 
			<br>Manuel Pena, Gregory Toussaint
			<br>copyright &copy; 2019
			</em>
		</footer>

</body>
</html>