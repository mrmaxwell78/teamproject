<!DOCTYPE html>
<html>
<head>
	<title>Team Project One</title>
	<link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">
	<link href="stylesheet/formCSS.css" rel="stylesheet">
<style>
body {
  background-image: url("img/blackbackground.png");
}
</style>	
</head>
<body>
<?php
include('InventoryConnection.php'); //DB connection
$dbAction =  $_GET['action']; //receive action for form


//START
if($dbAction == "update"){
	$RoomID = $_GET['id'];
	
	$select = "SELECT * FROM Rooms WHERE RoomID = $RoomID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();
		$RoomID = $row['RoomID'];
		$BuildingID = $row['BuildingID'];
		$RoomNumber = $row['RoomNumber'];
		$Capacity = $row['Capacity'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Rooms form
		</legend>
		<label for="RoomID">RoomID</label>
		<input type="text" name="RoomID" id="RoomID" value="<?php echo $RoomID ?>" required><br>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" value="<?php echo $BuildingID ?>" required><br>
		<label for="RoomNumber">Room Number</label>
		<input type="text" name="RoomNumber" id="RoomNumber" value="<?php echo $RoomNumber ?>" required><br>
		<label for="Capacity">Capacity</label>
		<input type="text" name="Capacity" id="Capacity" value="<?php echo $Capacity ?>" required><br>
		
		<button type="submit" name="update">Update</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['update'])){
		$RoomID = $_POST['RoomID'];
		$BuildingID = $_POST['BuildingID'];
		$RoomNumber = $_POST['RoomNumber'];
		$Capacity = $_POST['Capacity'];
		$sql = "UPDATE Rooms SET RoomID='$RoomID', BuildingID='$BuildingID', RoomNumber='$RoomNumber', Capacity='$Capacity' WHERE RoomID ='$RoomID'";
		$conn->query($sql);
		//echo $RoomID.' '.$BuildingID.' '.$RoomNumber.' '.$Capacity;
		header('Location: rooms.php');
	}
}
else if($dbAction == "delete"){
	$RoomID = $_GET['id'];
	
	$select = "SELECT * FROM Rooms WHERE RoomID = $RoomID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();	
		$RoomID = $row['RoomID'];
		$BuildingID = $row['BuildingID'];
		$RoomNumber = $row['RoomNumber'];
		$Capacity = $row['Capacity'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Rooms form
		</legend>
		<label for="RoomID">RoomID</label>
		<input type="text" name="RoomID" id="RoomID" value="<?php echo $RoomID ?>" required><br>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" value="<?php echo $BuildingID ?>" required><br>
		<label for="RoomNumber">Room Number</label>
		<input type="text" name="RoomNumber" id="RoomNumber" value="<?php echo $RoomNumber ?>" required><br>
		<label for="Capacity">Capacity</label>
		<input type="text" name="Capacity" id="Capacity" value="<?php echo $Capacity ?>" required><br>
		
		<button type="submit" name="delete">Delete</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['delete'])){
		$RoomID = $_POST['RoomID'];
		$sql = "DELETE FROM Rooms WHERE RoomID=$RoomID";
		$conn->query($sql);
		//echo $RoomID.' '.$BuildingID.' '.$RoomNumber.' '.$Capacity;
		header('Location: rooms.php');
	}
}
else if($dbAction == "insert"){
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Rooms form
		</legend>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" required><br>
		<label for="RoomNumber">Room Number</label>
		<input type="text" name="RoomNumber" id="RoomNumber" required><br>
		<label for="Capacity">Capacity</label>
		<input type="text" name="Capacity" id="Capacity" required><br>
		
		<button type="submit" name="insert">Insert</button>

		</fieldset>
	</form>
<?php
		if(isset($_POST['insert'])){
			$BuildingID = $_POST['BuildingID'];
			$RoomNumber = $_POST['RoomNumber'];
			$Capacity = $_POST['Capacity'];
			$sql = "INSERT INTO Rooms (BuildingID, RoomNumber, Capacity) VALUES('$BuildingID', '$RoomNumber', '$Capacity')";
			
			$conn->query($sql);
			echo $sql;
			//echo $BuildingID.' '.$RoomNumber.' '.$Capacity;
			header('Location: rooms.php');
		}
}else{
	echo 'Something went really wrong here!';
}
//END
$conn = null;
?>
   <div id="footer"></div>
     <footer>
			<em>
			<img src="img/group-icon2.png" alt="group icon" height="3%" width="3%">
			<br>Darly Dubreus, Grace Hechavarria, Mathew Maxwell, 
			<br>Manuel Pena, Gregory Toussaint
			<br>copyright &copy; 2019
			</em>
		</footer>
</body>
</html>
