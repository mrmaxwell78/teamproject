<!DOCTYPE html>
<html>
<head>
	<title>Team Project One</title>
	<link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">
	<link href="stylesheet/formCSS.css" rel="stylesheet">
<style>
body {
  background-image: url("img/blackbackground.png");
}
</style>	
</head>
<body>
<?php
include('InventoryConnection.php'); //DB connection
$dbAction =  $_GET['action']; //receive action for form


//START
if($dbAction == "update"){
	$ComputerID	= $_GET['id'];
	$select = "SELECT * FROM computers WHERE ComputerID = $ComputerID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();
		$ComputerID = $row['ComputerID'];
		$VendorID = $row['VendorID'];
		$MemorySize = $row['MemorySize'];
		$StorageSize = $row['StorageSize'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Buildings form
		</legend>
		<label for="ComputerID">Computer ID</label>
		<input type="text" name="ComputerID" id="ComputerID" value="<?php echo $ComputerID ?>" required><br>
		<label for="VendorID">Vendor ID</label>
		<input type="text" name="VendorID" id="VendorID" value="<?php echo $VendorID ?>" required><br>
		<label for="MemorySize">Memory Size</label>
		<input type="text" name="MemorySize" id="MemorySize" value="<?php echo $MemorySize ?>" required><br>
		<label for="StorageSize">Storage Size</label>
		<input type="text" name="StorageSize" id="StorageSize" value="<?php echo $StorageSize ?>" required><br>
		
		<button type="submit" name="update">Update</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['update'])){
		$ComputerID = $_POST['ComputerID'];
		$VendorID = $_POST['VendorID'];
		$MemorySize = $_POST['MemorySize'];
		$StorageSize = $_POST['StorageSize'];
		$sql = "UPDATE computers SET ComputerID='$ComputerID', VendorID='$VendorID', MemorySize='$MemorySize', StorageSize='$StorageSize' WHERE ComputerID ='$ComputerID'";
		$conn->query($sql);
		//echo $ComputerID.' '.$VendorID.' '.$MemorySize. ' ' .$StorageSize;
		header('Location: computers.php');
	}
}
else if($dbAction == "delete"){
	$ComputerID = $_GET['id'];
	
	$select = "SELECT * FROM computers WHERE ComputerID = $ComputerID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();	
		$ComputerID = $row['ComputerID'];
		$VendorID = $row['VendorID'];
		$MemorySize = $row['MemorySize'];
		$StorageSize = $row['StorageSize'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Buildings form
		</legend>
		<label for="ComputerID">Computer ID</label>
		<input type="text" name="ComputerID" id="ComputerID" value="<?php echo $ComputerID ?>" required><br>
		<label for="VendorID">Vendor ID</label>
		<input type="text" name="VendorID" id="VendorID" value="<?php echo $VendorID ?>" required><br>
		<label for="MemorySize">Memory Size</label>
		<input type="text" name="MemorySize" id="MemorySize" value="<?php echo $MemorySize ?>" required><br>
		<label for="StorageSize">Storage Size</label>
		<input type="text" name="StorageSize" id="StorageSize" value="<?php echo $StorageSize ?>" required><br>
		
		<button type="submit" name="delete">Delete</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['delete'])){
		$ComputerID = $_POST['ComputerID'];
		$sql = "DELETE FROM computers WHERE ComputerID=$ComputerID";
		$conn->query($sql);
		//echo $ComputerID.' '.$VendorID.' '.$MemorySize. ' ' .$StorageSize;
		header('Location: computers.php');
	}
}
else if($dbAction == "insert"){
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Buildings form
		</legend>
		<label for="VendorID">Vendor ID</label>
		<input type="text" name="VendorID" id="VendorID" required><br>
		<label for="MemorySize">Memory Size</label>
		<input type="text" name="MemorySize" id="MemorySize" required><br>
		<label for="StorageSize">Storage Size</label>
		<input type="text" name="StorageSize" id="StorageSize" required><br>
		
		<button type="submit" name="insert">Insert</button>

		</fieldset>
	</form>
<?php
		if(isset($_POST['insert'])){
			$VendorID = $_POST['VendorID'];
			$MemorySize = $_POST['MemorySize'];
			$StorageSize = $_POST['StorageSize'];
			$sql = "INSERT INTO computers (VendorID, MemorySize, StorageSize) VALUES('$VendorID', '$MemorySize', '$StorageSize')";
			
			$conn->query($sql);
			echo $sql;
			//echo $VendorID.' '.$MemorySize, ' '.$StorageSize;
			header('Location: computers.php');
		}
}else{
	echo 'Something went really wrong here!';
}
//END
$conn = null;
?>
<div id="footer"></div>
<footer>
			<em>
			<img src="img/group-icon2.png" alt="group icon" height="3%" width="3%">
			<br>Darly Dubreus, Grace Hechavarria, Mathew Maxwell, 
			<br>Manuel Pena, Gregory Toussaint
			<br>copyright &copy; 2019
			</em>
		</footer>

</body>
</html>