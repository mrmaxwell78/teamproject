<!DOCTYPE html>
<html>
<head>
	<title>Team Project One</title>
	<link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">
	<link href="stylesheet/formCSS.css" rel="stylesheet">
<style>
body {
  background-image: url("img/blackbackground.png");
}
</style>	
</head>
<body>
<?php
include('InventoryConnection.php'); //DB connection
$dbAction =  $_GET['action']; //receive action for form


//START
if($dbAction == "update"){
	$BuildingID	= $_GET['id'];
	$select = "SELECT * FROM Buildings WHERE BuildingID = $BuildingID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();
		$BuildingID = $row['BuildingID'];
		$BuildingNo = $row['BuildingNo'];
		$BuildingName = $row['BuildingName'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Buildings form
		</legend>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" value="<?php echo $BuildingID ?>" required><br>
		<label for="BuildingNo">BuildingNo</label>
		<input type="text" name="BuildingNo" id="BuildingNo" value="<?php echo $BuildingNo ?>" required><br>
		<label for="BuildingName">Building Name</label>
		<input type="text" name="BuildingName" id="BuildingName" value="<?php echo $BuildingName ?>" required><br>
		
		<button type="submit" name="update">Update</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['update'])){
		$BuildingID = $_POST['BuildingID'];
		$BuildingNo = $_POST['BuildingNo'];
		$BuildingName = $_POST['BuildingName'];
		$sql = "UPDATE Buildings SET BuildingID='$BuildingID', BuildingNo='$BuildingNo', BuildingName='$BuildingName' WHERE BuildingID ='$BuildingID'";
		$conn->query($sql);
		//echo $BuildingID.' '.$BuildingNo.' '.$BuildingName;
		header('Location: buildings.php');
	}
}
else if($dbAction == "delete"){
	$BuildingID = $_GET['id'];
	
	$select = "SELECT * FROM Buildings WHERE BuildingID = $BuildingID";
	$result = $conn->query($select);
		
	if($result !== FALSE){
		$row=$result->fetch();	
		$BuildingID = $row['BuildingID'];
		$BuildingNo = $row['BuildingNo'];
		$BuildingName = $row['BuildingName'];
	}else{
		print("error " . count($result));
	}
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Buildings form
		</legend>
		<label for="BuildingID">Building ID</label>
		<input type="text" name="BuildingID" id="BuildingID" value="<?php echo $BuildingID ?>" required><br>
		<label for="BuildingNo">BuildingNo</label>
		<input type="text" name="Capacity" id="BuildingNo" value="<?php echo $BuildingNo ?>" required><br>
		<label for="BuildingName">Building Name</label>
		<input type="text" name="BuildingName" id="BuildingName" value="<?php echo $BuildingName ?>" required><br>
		
		<button type="submit" name="delete">Delete</button>

		</fieldset>
	</form>
<?php
	if(isset($_POST['delete'])){
		$BuildingID = $_POST['BuildingID'];
		$sql = "DELETE FROM Buildings WHERE BuildingID=$BuildingID";
		$conn->query($sql);
		//echo $BuildingID.' '.$BuildingNo.' '.$BuildingName;
		header('Location: buildings.php');
	}
}
else if($dbAction == "insert"){
?>
	<div id="form"></div>
	<form action="" method="POST">
		<fieldset>
		<legend> 
		Buildings form
		</legend>
		<label for="BuildingNo">BuildingNo</label>
		<input type="text" name="BuildingNo" id="BuildingNo" required><br>
		<label for="BuildingName">Building Name</label>
		<input type="text" name="BuildingName" id="BuildingName" required><br>
		
		<button type="submit" name="insert">Insert</button>

		</fieldset>
	</form>
<?php
		if(isset($_POST['insert'])){
			$BuildingNo = $_POST['BuildingNo'];
			$BuildingName = $_POST['BuildingName'];
			$sql = "INSERT INTO Buildings (BuildingNo, BuildingName) VALUES('$BuildingNo', '$BuildingName')";
			
			$conn->query($sql);
			//echo $sql;
			//echo $BuildingNo.' '.$BuildingName;
			header('Location: buildings.php');
		}
}else{
	echo 'Something went really wrong here!';
}
//END
$conn = null;
?>
<div id="footer"></div>
<footer>
			<em>
			<img src="img/group-icon2.png" alt="group icon" height="3%" width="3%">
			<br>Darly Dubreus, Grace Hechavarria, Mathew Maxwell, 
			<br>Manuel Pena, Gregory Toussaint
			<br>copyright &copy; 2019
			</em>
		</footer>

</body>
</html>