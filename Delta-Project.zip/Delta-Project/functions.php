<?php
function displayHeader(){
echo '
<!DOCTYPE html>
    <html>
    <head>
    <title>Index</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>';
   
}
?>
<?php
function displayPageFooter() {
 echo '
  </body>
</html>';

}
?>
